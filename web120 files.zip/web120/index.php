<?php include 'includes/header.php';?>

<!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
 <img src="images/desktop.jpg" class="desktop" alt="" />
 <img src="images/phone.jpg" class="phone" alt="" /><br>
 <p>Hi, my name is Matt. I love the beautful nature of the Pacific Northwest, illustration, digital art, and technology. I currently work in urban planning and have a degree in Community Development from Portland State. I decided to study web design as a way to build a portfolio and explore grad school for UX design.</p><br>

</section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
 <h3>Goals</h3>
 <img src="images/tablet.jpg" class="tablet" alt="" />
 <p>I hope to incorporate good design with strong coding skills so I can create dynamic, accessible websites. </p>

</aside>
<!-- END RIGHT COL -->
 
<?php include 'includes/footer.php';?>
